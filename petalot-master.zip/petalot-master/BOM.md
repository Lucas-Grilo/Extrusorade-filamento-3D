| Qty    | Name                                                                                          | Aliexpress (affiliate)                     |
| ------ | --------------------------------------------------------------------------------------------- | ------------------------------------------ |
|        | ----------- **Bottle Cutter** ------------ |  |
| 2      | 608 RS bearings                                                                               | https://s.click.aliexpress.com/e/_DFmmUC5  |
| 3(5)   | Hex Nut M8                                                                                    | https://s.click.aliexpress.com/e/_DlmzKtL  |
| 3      | Flat Washer M8 16x1x1.5                                                                       | https://s.click.aliexpress.com/e/_Dk397ED  |
| 2      | M8 Hex Nylon Insert Lock Nut Self-locking Locknut                                             | https://s.click.aliexpress.com/e/_DeFb56h  |
| 2      | M8x50mm Threaded Rod                                                                          | https://s.click.aliexpress.com/e/_DeTWIUt  |
| 1      | M8x30mm Threaded Rod                                                                          | https://s.click.aliexpress.com/e/_DeTWIUt  |
| 1      | 48cm M6 Rod
|        | ----------- **Electronics** -------------- |  |
| 1      | Power Supply 12v 5A                                                                           | https://s.click.aliexpress.com/e/_Dd9tuCD  |
| 1      | Wemos D1 MINI V4.0                                                                            | https://s.click.aliexpress.com/e/_DCS2eTP  |
| 1      | Mini DC-DC 12-24V To 5V 3A Step Down                                                          | https://s.click.aliexpress.com/e/_DDFlE5x  |
| 1      | Mini Micro Limit Switch Roller Lever Arm  (MS-1A-14.5-P)                                      | https://s.click.aliexpress.com/e/_DdoNg8z  |
| 1      | A4988 DRV8825 Stepper Motor Driver With Heat sink                                             | https://s.click.aliexpress.com/e/_DFlq3ud  |
| 1      | Nema 17 stepper motor 42 motor height 38mm 1.2A D shaped shaft                                | https://s.click.aliexpress.com/e/_DFHxH3L  |
| 1      | IRLZ44N MOSFET                                                                                | https://s.click.aliexpress.com/e/_DdfBlgH  |
| 1      | Hotend MK8 12V 40W                                                                            | https://s.click.aliexpress.com/e/_DnlMNy5  |
| 1      | capacitor 16V 100uf                                                                           | https://s.click.aliexpress.com/e/_DBG3FJL  |
| 1      | pin header Male and Female                                                                    | https://s.click.aliexpress.com/e/_DcGRnY9  |
| 3      | Terminal Block Connector 2P                                                                   | https://s.click.aliexpress.com/e/_DkqRgFn  |
| 2      | 10K ohms resistors                                                                            | https://s.click.aliexpress.com/e/_DeT9AAz  |
| 50cm   | 2 wire cable for limit switch, digital signal                                                 | https://s.click.aliexpress.com/e/_Dlnn1bd  |
| 50cm   | 2 wire cable for 5A+                                                                          | https://s.click.aliexpress.com/e/_Dlnn1bd |
| 1      | 10A 250V Inlet Module Plug Rocker Switch Male Power Socket 3 Pin IEC320 C14 switch + Fuse New | https://s.click.aliexpress.com/e/_DmuNpxf  |
|        | ----------- **Hardware** ---------------- |  |
| 18     | Screw M2 x 16mm (100pcs) (union between large gears and pulley)                               | https://s.click.aliexpress.com/e/_Dcg0sln  |
| 1      | MK8 Brass Nozzle 0.4MM                                                                        | https://s.click.aliexpress.com/e/_ANswWD   |
| 4      | Bearing 8x22x7 mm 608ZZ                                                                       | https://s.click.aliexpress.com/e/_DFmmUC5  |
| 1      | Stainless Steel 90 Degree Angle Bracket Corner 20x20mm                                        | https://s.click.aliexpress.com/e/_ACOtVF   |
| 2      | M8 x 100mm A2 Hex Head Screw Bolt (instead I use 2x 8mm rod thereaded cut to 10cm)            | https://s.click.aliexpress.com/e/_AY2LNb   |
| 2(4)   | M8 Hex Nylon Insert Lock Nut Self-locking Locknut                                             | https://s.click.aliexpress.com/e/_DeFb56h  |
| 3      | M3 8mm Bolt for the motor gear, motor mount and electronic box                                | https://s.click.aliexpress.com/e/_DelUMSF  |
| 2      | M3 OD 4.2mm Insert Nut for motor mount and electronic box                                     | https://s.click.aliexpress.com/e/_DDwB54l  |
| 2      | M3 14mm Bolt for motor mount                                                                  | https://s.click.aliexpress.com/e/_DelUMSF  |
| 50cm   | Paracord 2mm(nylon string) (I used polyester thread for kite handles)                         | https://s.click.aliexpress.com/e/_DEO5fqN  |
| 1      | 1.7mm drill bit                                                                               | https://s.click.aliexpress.com/e/_DD1SYVV  |
