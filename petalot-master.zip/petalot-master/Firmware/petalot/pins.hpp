#define PIN_EN    D1
#define PIN_STEP  D2
#define PIN_DIR   D3

#define PIN_THERMISTOR A0
#define PIN_HEATER D0

//v1 and v1.1
#define PIN_FILAMENT D7
